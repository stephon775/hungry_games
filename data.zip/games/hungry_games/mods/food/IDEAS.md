Recipes coming on release of this mod.
Read Code to find recipes before then

Items
* Cup / Glass
* Mug
* Oven

Diary
* Butter
* Cheese

Sandwiches
* Venison Sandwich
* Cheese Sandwich
* Burger

Baking
* Bread
* Bread Slices
* Buns

Cakes
* Plain Cake
* Chocolate Cake
* Carrot Cake

Tarts
* Strawberry Tart
- Chocolate Tart

Crumbles
* Rhubarb Crumble

Drinks
* Apple Juice
* Cactus Juice
* Coffee
* Coffee Beans
* Hot Chocolate
- Chocolate Milk Shake
- Banana Milk Shake
- Strawberry Milk Shake

Misc
* Cigerettes (takes 1 life away)
* Cooked Meat
* Sugar